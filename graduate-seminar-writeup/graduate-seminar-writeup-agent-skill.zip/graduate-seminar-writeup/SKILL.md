---
name: graduate-seminar-writeup
description: Use for Graduate Seminar talks when Nathan provides a transcript, notes, or chat context. Produce a full whitepaper and a four-section seminar writeup in Nathan's academic style and Word format.
metadata:
  author: Nathan Conklin
  version: "1.0.0"
---

# Graduate Seminar Writeup

Create two separate artifacts from one Graduate Seminar talk:

1. a full technical whitepaper; and
2. a concise Graduate Seminar response with four substantive sections.

This package is self-contained. Do **not** require separately installed `chat-to-whitepaper`, `nathan-speak`, or `nathan-whitepaper` skills. Their workflows are bundled under `references/` so the same skill folder can be installed unchanged in any Agent Skills-compatible client.

## Required bundled references

Before drafting, read these files from this skill directory:

- [`references/seminar-workflow.md`](references/seminar-workflow.md) for the complete orchestration and section requirements;
- [`references/chat-to-whitepaper.md`](references/chat-to-whitepaper.md) for Nathan's full-whitepaper workflow;
- [`references/nathan-speak.md`](references/nathan-speak.md) for Nathan's prose style; and
- [`references/nathan-whitepaper.md`](references/nathan-whitepaper.md) for Nathan's Word formatting and converter workflow.

Treat these bundled files as authoritative for this skill. If similarly named skills are installed separately, do not depend on them unless the user explicitly asks to substitute them.

## Environment portability

Use the current client's normal facilities for attachments, file reading, code execution, and user-visible artifact delivery. When a bundled reference gives an example filesystem path, translate it to the current environment's writable working directory or output directory without changing the requested content, style, or document layout.

If a verification utility such as LibreOffice, `pdfinfo`, or image inspection is unavailable, perform every verification step that the current environment supports and clearly report the unavailable check. Do not silently skip validation.

## Execution contract

- Use the transcript, notes, or relevant current chat context as the primary source.
- Produce both document sets; do not merge them.
- Preserve source fidelity and mark uncertain facts with `[TODO: ...]` rather than guessing.
- The shorter seminar document has **no Abstract and no Introduction**. It begins immediately with `1. Presentation Summary` after the title/contact block.
- Apply the bundled `nathan-speak` rules to the seminar writeup.
- Apply the bundled `nathan-whitepaper` workflow to both Word documents.
- Deliver the two `.docx` files plus their Markdown sources.
- Follow the detailed quality checks and word-count requirements in `references/seminar-workflow.md`.
