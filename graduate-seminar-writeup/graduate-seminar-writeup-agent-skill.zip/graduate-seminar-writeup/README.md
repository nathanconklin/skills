# graduate-seminar-writeup

Portable Agent Skills package for Nathan Conklin's Graduate Seminar workflow.

## Package layout

```text
graduate-seminar-writeup/
├── SKILL.md
├── README.md
└── references/
    ├── seminar-workflow.md
    ├── chat-to-whitepaper.md
    ├── nathan-speak.md
    └── nathan-whitepaper.md
```

The ZIP contains the `graduate-seminar-writeup/` folder as its top-level entry. No vendor-specific manifest is required.

## Installation

- **Claude web/desktop:** Upload the ZIP as a custom Skill from Customize > Skills.
- **Claude Code:** Unzip and place the `graduate-seminar-writeup` folder under `~/.claude/skills/` for personal use or `.claude/skills/` for a project.
- **ChatGPT web:** Upload the ZIP from the Skills creation/upload flow when Skills are enabled for the account/workspace.
- **Codex:** Install the same folder with Codex's skill installer or place it in the skill directory used by the current Codex installation. The built-in OpenAI skill installer currently installs into `$CODEX_HOME/skills` (default `~/.codex/skills`).

The installed skill folder itself is identical on every platform.
