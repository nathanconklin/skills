# Goals G04-G07

# G04 — Validate every reference and correct verified metadata

## Goal

Establish that every cited work is real and that its bibliography metadata is accurate.

## Verification hierarchy

Prefer authoritative or primary bibliographic sources. Use multiple sources when helpful.

For DOI-bearing scholarly works, prioritize:
1. DOI/Crossref metadata;
2. publisher or official proceedings page;
3. ACM Digital Library, IEEE Xplore, Springer, Elsevier, Wiley, USENIX, or the relevant publisher/library;
4. DBLP for computer-science bibliographic corroboration;
5. official arXiv record for preprints;
6. institutional repository or university record for theses/reports;
7. authoritative library/catalog records for books.

Search engines and scholarly indexes may be used for discovery, but do not treat a search-result snippet alone as proof.

## Verify at minimum

For every reference where applicable:
- work exists;
- title;
- author names and order;
- year/date;
- publication venue;
- volume/issue;
- page range or article number;
- publisher;
- DOI;
- edition/ISBN for books when useful;
- arXiv identifier/version context for preprints when relevant.

## Correction policy

- **VERIFIED** — current metadata is supported.
- **CORRECTED** — authoritative evidence supports a correction; update the References entry.
- **UNRESOLVED** — evidence conflicts or the intended work cannot be established confidently; do not guess.

When correcting a title/author/year, keep the same `source_id` only if evidence shows it is the same intended work. If the evidence suggests the citation may actually point to a different work, flag it instead of silently changing source identity.

## G04 validation gate

- Every bibliography entry has a validation status.
- Every automatic correction has authoritative support.
- No nonexistent work is falsely marked verified.
- Corrections did not detach bookmarks or change citation targets.
- Non-citation content fingerprint remains unchanged.

---

# G05 — Recheck alphabetical order

## Goal

Bibliographic corrections in G04 may change author names or other sort keys. Re-sort if required.

## Procedure

1. Recompute sort keys from corrected metadata.
2. Re-sort whole bookmarked reference entries as necessary.
3. Update all Word fields.
4. Revalidate the source-identity map.

## G05 validation gate

- References are alphabetically correct after metadata corrections.
- All citations still resolve to the intended source.
- New displayed citation numbers match the final sorted order.
- Non-citation content fingerprint remains unchanged.

---

# G06 — Add a canonical URL to every reference

## Goal

Every reference entry should end with a visible, usable URL that points to the cited work or its authoritative record.

## URL priority

Choose the most canonical stable URL available in this order:
1. canonical DOI URL: `https://doi.org/<doi>`;
2. official publisher / digital-library / proceedings landing page;
3. official arXiv/preprint page;
4. institutional repository or authoritative catalog record;
5. another authoritative stable source page.

Avoid when a better option exists:
- Google/Google Scholar search URLs;
- generic search-result pages;
- temporary session links;
- tracking-heavy redirect URLs;
- link shorteners;
- unofficial mirrors;
- direct PDF URLs when a stable canonical landing page exists.

## Procedure

1. Find the canonical URL even if the original reference omitted one.
2. Append a visible URL to the end of **every** reference.
3. Prefer DOI URLs whenever a DOI exists.
4. Make the URL clickable in Word when technically practical without altering unrelated formatting.
5. Do not replace an authoritative DOI URL with a less authoritative web page.

Example ending:

```text
... ACM, New York, NY, USA. https://doi.org/10.xxxx/xxxxx
```

## G06 validation gate

- Every reference has a URL or is explicitly marked `UNRESOLVED — no authoritative URL located` in the audit.
- URLs are placed only in the References section.
- All URLs correspond to the same work as the associated source identity.
- Citation bookmarks/fields remain intact.
- Non-citation content fingerprint remains unchanged.

---

# G07 — Validate every URL

## Goal

Prove that each added URL is live and resolves to the correct work.

## Procedure

For each URL:
1. open/fetch it;
2. follow normal redirects;
3. reject obvious error/404/soft-404/access-denied landing pages when a better canonical URL can be found;
4. inspect the destination identity;
5. verify that destination metadata matches the associated reference, especially title/author/DOI;
6. replace broken or mismatched links with a verified canonical URL when available.

A URL is not considered valid merely because the server returns success; the destination must correspond to the cited work.

Pay special attention to:
- DOI redirects;
- proceedings sites that changed domains;
- arXiv version links;
- publisher URLs with obsolete identifiers;
- URLs that resolve to a journal homepage instead of the actual article.

## G07 validation gate

Assign each reference URL a status:
- `URL VERIFIED`;
- `URL REPLACED AND VERIFIED`;
- `URL UNRESOLVED`.

No reference should silently retain a known broken or wrong URL.

---

