# Goals G01-G03

# G01 — Convert citations to real Word cross-references

## Goal

Convert all safely resolvable citations into real Microsoft Word cross-reference fields connected to the correct numbered entry in the References section.

## Procedure

1. Normalize the References section into a true automatic single-level numbered list if it is not already one.
   - Prefer list-number display such as `[1]`, `[2]`, etc.
   - Do not manually type the reference numbers into reference text.

2. Assign every unique reference a stable bookmark name that remains attached to that source when entries are reordered.
   - Example naming pattern: `_Cite_<stable_id>`.
   - Bookmark names must be unique and valid for Word.
   - Bookmark the numbered reference item in a way compatible with Word numbered-item cross-references.

3. Replace each resolvable manual numeric citation with a real field tied to its source bookmark.
   - Desired visible form: `[1]`.
   - Conceptual field construction: literal `[` + `{ REF _Cite_xxx \n \h }` + literal `]`.

4. Convert author-year citations when they resolve unambiguously to an existing bibliography entry.
   - Parenthetical: `(Smith, 2024)` -> `[N]`.
   - Narrative: `Smith (2024)` -> `Smith [N]`; preserve the author text exactly and replace only the citation/year portion.
   - If an author-year citation is ambiguous, do not guess. Flag it.

5. Convert grouped citations to separate references.
   - `[1, 2]` -> `[1], [2]`.
   - `[1–3]` -> `[1], [2], [3]` if the original range can be mapped safely.
   - Multi-work author-year groups should likewise become discrete numbered fields.

6. Detect and report:
   - citations with no matching bibliography entry;
   - bibliography entries never cited;
   - citations that point to a nonexistent bookmark/field;
   - duplicate reference entries.

7. Consolidate exact/near-exact duplicate bibliography entries only when source identity is unambiguous.
   - Pick one canonical entry.
   - Redirect all citations to its bookmark.
   - Remove only the duplicate entry, not a genuinely distinct work.

8. Update and finalize field results without creating an open-time warning.
   - When Microsoft Word automation is available, update fields during generation (`Ctrl+A`, `F9` or equivalent) and save the resulting cached values before delivery.
   - In programmatic OOXML workflows, calculate/set the cached display result for each inserted `REF` field to its current bibliography number.
   - **Do not** add or enable `<w:updateFields w:val="true"/>` in `word/settings.xml` merely to make Word recalculate fields when the document opens.
   - Once an inserted citation `REF` field has the correct cached result, do not leave its begin field character marked `w:dirty="true"` solely to force an update at open. Remove the dirty marker (or set it false) for skill-created citation fields.
   - Keep fields live and manually updateable. Do not set `w:fldLock="true"` and do not flatten fields to text.
   - Do not assume cached display text alone proves the field target is correct; validate the field code, bookmark target, and expected number structurally.

## G01 validation gate

Before G02, prove all of the following:
- every safely resolvable citation maps to exactly the intended source identity;
- every created `REF` field references an existing bibliography bookmark;
- every bibliography bookmark identifies exactly one source;
- no cross-reference reports `Error! Reference source not found.`;
- no blind numeric substitution was used;
- grouped citations are discrete `[N], [M]` fields;
- the set of cited source identities before and after G01 is unchanged, except for explicitly consolidated duplicates;
- the non-citation content fingerprint is unchanged;
- skill-created citation fields have correct cached results and are not dependent on update-on-open behavior.

If any mapping fails, repair it before G02.

---

# G02 — Format references in ACM style

## Goal

Format each bibliography entry according to ACM reference conventions while changing only the References section.

## Rules

Use ACM numbered-reference conventions and retain the numbered bibliography. The bibliography will later be alphabetized by first author/organization.

For each reference, identify its source type and format the available verified metadata appropriately, such as:
- journal article;
- conference/proceedings paper;
- book;
- chapter;
- technical report;
- thesis/dissertation;
- preprint/arXiv work;
- web publication or dataset when legitimately cited.

General ACM-oriented requirements:
- Prefer full author first names when authoritative metadata provides them.
- Preserve the correct author order for the work.
- Include title, year, venue, volume/issue, pages/article number, publisher/proceedings information, and DOI when applicable and verifiable.
- Do not fabricate missing metadata.
- Normalize punctuation, spacing, capitalization, and source-type structure to ACM reference form.
- Do not convert the body to author-year style.
- Do not modify paper prose while formatting references.

G06 will ensure every entry ends with a verified URL, so do not invent a URL during this pass merely to make an entry look complete.

## G02 validation gate

- Every reference has a recognized source type or is explicitly marked unresolved.
- Formatting changes are confined to the References section.
- Citation bookmarks remain attached to their correct source identities.
- All in-text `REF` fields still target the same source identities.
- Non-citation content fingerprint remains unchanged.

---

# G03 — Alphabetize references and safely renumber citations

## Goal

Sort the References section alphabetically while preserving citation-to-source identity.

## Sort order

Primary sort:
1. first personal author's surname;
2. organization/corporate author when no personal author exists;
3. title when no author can be identified.

Tie-breakers:
1. remaining author list;
2. publication year;
3. normalized title.

Use a stable, case-insensitive comparison and handle diacritics consistently.

## Procedure

1. Sort **reference entries as whole units**, carrying their bookmarks with them.
2. Allow Word automatic numbering to assign the new numeric order.
3. Never renumber citations by replacing visible numbers.
4. Update all `REF` fields so each citation displays the number of its source's new position.
5. Rebuild/check `source_id -> bookmark -> new_number -> citation_locations`.

## G03 validation gate

- Reference list is alphabetized according to the rules above.
- Each source retains the same stable bookmark/source identity.
- Every citation still points to the same scholarly work as before sorting.
- Displayed numeric citations match the newly sorted bibliography after field update.
- No missing, duplicated, or swapped citation targets exist.
- Non-citation content fingerprint remains unchanged.

---

