# Goals G08-G10

# G08 — Final document integrity and citation audit

## Goal

Confirm that G01–G07 cleaned the citations/references without changing the paper itself.

## A. Citation/reference integrity

Rebuild the citation map from the final DOCX rather than trusting the prior in-memory map.

Verify:
- every in-text citation field targets an existing source bookmark;
- every field displays the expected current number after update;
- every citation maps to the same intended source identity established at preflight;
- all multi-source citations are separate (`[1], [2]`);
- no broken `REF` fields;
- no missing citation target;
- no accidental duplicate citations created by conversion;
- exact duplicate bibliography entries have been safely consolidated when appropriate;
- uncited references and citations-without-reference are explicitly reported.

## B. Alphabetical/reference integrity

Verify:
- final References order is correct;
- automatic numbering is sequential;
- each number occurs exactly once in the reference list;
- ACM formatting is still intact;
- each entry ends with the correct canonical URL;
- G04/G07 validation statuses are represented in the audit report.

## C. Non-citation content freeze

Compare the final semantic non-citation fingerprint against the preflight baseline.

The result must show no substantive text changes outside:
- citation spans/fields;
- References/Bibliography entries.

Also compare structural safeguards where available:
- headings and heading order;
- paragraph/table/figure counts;
- sections;
- captions;
- equations;
- headers/footers;
- footnotes/endnotes;
- images/media relationships.

If any unrelated content changed, revert or repair it before G09.

## D. DOCX package-change whitelist

When performing OOXML/package diffs, investigate changes outside the expected areas. Expected changes may include:
- `word/document.xml` for citation fields/bookmarks and References content;
- `word/numbering.xml` when bibliography numbering must be created/adjusted;
- `word/settings.xml` only if preserving or intentionally restoring a pre-existing source-document setting; this skill must not newly enable update-on-open for citation refresh;
- relevant relationship parts if external hyperlinks are created for reference URLs.

Unexpected modifications to styles, media, section geometry, headers/footers, theme, tracked changes, or other document parts must be explained and normally reverted.

## E. Field finalization, open-safety, and visual QA

1. Update fields during generation using Microsoft Word when available (`Ctrl+A`, `F9`) or a reliable programmatic field-result mechanism. Save correct cached field results into the DOCX before delivery.
2. Ensure no `Error! Reference source not found.` messages remain.
3. Inspect `word/settings.xml`. The skill must not add or enable `<w:updateFields w:val="true"/>` merely to refresh citations when Word opens the file. If this setting was introduced by the skill, remove it before delivery. Preserve a pre-existing source-document setting unless the user asks otherwise, but report it if it may cause an open-time prompt.
4. Inspect skill-created citation fields:
   - field instruction must be an internal `REF` targeting an existing bookmark, normally `REF <bookmark> \n \h`;
   - cached result must already equal the bibliography item's final current number;
   - after the cached result is synchronized, the field must not remain marked `w:dirty="true"` solely to force recalculation at open;
   - do not lock or flatten the field.
5. Compare field-code types before and after editing. The skill must not introduce external-link field types such as `LINK`, `INCLUDETEXT`, `INCLUDEPICTURE`, `DDE`, `DDEAUTO`, `DATABASE`, or `RD`. Normal URL hyperlinks represented as hyperlink relationships are permitted and should remain clickable.
6. Perform an **open-warning risk audit**. If the package contains a skill-introduced update-on-open setting, dirty skill-created citation fields that depend on open-time recalculation, or newly introduced external field codes, repair them before delivery.
7. Render the DOCX to page images.
8. Inspect every page at 100% zoom.
9. Confirm no clipping, reflow damage, missing glyphs, broken tables, or displaced figures occurred.
10. Re-render after any repair.

Do not flatten the final citation fields merely to make a renderer look correct.

## G08 validation gate

G09 may proceed only when:
- structural citation integrity passes;
- reference order/numbering passes;
- URLs and validation status are accounted for;
- non-citation semantic content matches baseline;
- field/open-safety audit passes with no skill-introduced update-on-open dependency;
- final render inspection passes.

If unresolved bibliographic items remain, the document may still be delivered only if the unresolved items are clearly disclosed in the audit and were not guessed.

---

# G09 — Produce final Word and BibTeX outputs

## Required outputs

Produce all of the following:

### 1. Updated Word document

Filename pattern:

```text
<original-stem>-references-cleaned.docx
```

Requirements:
- true Word citation `REF` fields remain intact;
- reference bookmarks remain intact;
- References section is alphabetized and numbered;
- references are ACM formatted;
- every reference has a canonical URL where resolvable;
- document passes G08.

### 2. `BibTex.md`

Create a Markdown file containing the complete final bibliography in a fenced `bibtex` code block.

Requirements:
- one BibTeX record per final bibliography entry;
- metadata reflects the final validated reference data;
- include DOI and URL fields when verified;
- escape BibTeX special characters correctly;
- use deterministic, human-readable unique keys when possible;
- do not use reference-list numbers as BibTeX keys.

### 3. `references.bib`

Also create a conventional raw BibTeX file containing the same entries as `BibTex.md`, without Markdown fences.

### 4. `Reference-Audit.md`

Create an audit report containing at minimum:
- source/reference number;
- short title;
- validation status (`VERIFIED`, `CORRECTED`, `UNRESOLVED`);
- DOI if available;
- final URL;
- URL status;
- any metadata corrections made;
- duplicate handling;
- uncited references;
- citations with missing/ambiguous references;
- confirmation that G08 non-citation integrity passed or details of any unresolved issue.

## BibTeX key guidance

Prefer deterministic keys such as:

```text
FirstAuthorSurnameYYYYShortTitleWord
```

Disambiguate collisions with a meaningful suffix (`a`, `b`, venue keyword, or additional title word).

Preserve Unicode/LaTeX safety as appropriate for the target BibTeX consumer.

---

# G10 — Recommend 3–4 additional literature references

## Goal

Search the scholarly literature in the context of the paper and identify three or four strong references the author may want to consider adding.

**Do not add these works to the Word document or final bibliography.** They are recommendations only.

## Procedure

1. Read enough of the paper to understand:
   - research problem;
   - central claims;
   - related-work framing;
   - methodology;
   - major concepts/technologies;
   - apparent literature gaps.

2. Search current scholarly literature as well as important seminal work when relevant.

3. Prefer works that add genuine value, such as:
   - direct prior work the paper appears to be missing;
   - a recent closely related paper;
   - a foundational/seminal reference supporting a major claim;
   - a contrasting result or alternative method;
   - a user study/evaluation if the paper discusses HCI but lacks empirical grounding;
   - a primary source instead of a secondary citation.

4. Validate each suggested work using the same rigor as G04/G07.

5. Do not recommend a work already present in the bibliography under a variant citation.

## Required output: `Suggested-References.md`

For each of 3–4 recommendations include:
- full ACM-style citation;
- BibTeX entry or BibTeX-ready metadata;
- DOI and canonical URL;
- why the work is relevant;
- what claim/topic it would support;
- recommended insertion location in the paper;
- section heading plus the exact sentence or the opening words of the paragraph where it would fit best;
- a short explanation of how the author might use the source, **without rewriting the paper or inserting the citation automatically**.

Suggested format:

```markdown
## Candidate 1 — <short title>

**Reference:** ...
**DOI/URL:** ...
**Why it matters:** ...
**Suggested location:** Section 3.2, paragraph beginning “...”
**Would support:** ...
**Status:** Verified
```

Favor quality and relevance over novelty for novelty's sake.

---

