# Preflight, Citation Recognition, Duplicates, and Audit Model

# Inputs

Primary input:
- One Microsoft Word `.docx` document containing scholarly citations and a References/Bibliography section.

Optional inputs:
- Existing `.bib` / BibTeX file.
- DOI list, EndNote/Zotero/Mendeley export, or other reference metadata supplied by the user.
- User-supplied citation/reference formatting requirements that override defaults in this skill.

If more than one candidate Word file is present and the intended source is not obvious, use the file most clearly identified by the user's request. Do not modify the original in place unless the user explicitly asks for that behavior.

---

# Preflight: create the immutable baseline

Before G01, create an internal audit model of the source document.

## A. Locate the reference section

Identify the bibliography section using headings such as:
- `References`
- `REFERENCES`
- `Bibliography`

Do not rename the heading unless the user explicitly asks.

Determine the exact beginning and end of the reference entries. Avoid accidentally treating appendices or text after the References section as bibliography entries.

## B. Inventory every reference

For every reference entry, record at minimum:
- original position/number, if present;
- exact original text;
- parsed authors or organization;
- year;
- title;
- venue/publisher;
- DOI, if present;
- URL, if present;
- normalized title fingerprint;
- stable internal `source_id`.

A useful stable identity is a deterministic hash derived from verified identity-bearing metadata such as normalized title + first author + year + DOI when available. Do not use the current numeric reference number as source identity.

## C. Inventory every citation

Scan all document story content that can contain citations, including body paragraphs, tables, captions, footnotes/endnotes, and other reachable Word text structures.

Recognize at least:
- manually typed numeric citations: `[1]`, `[12]`;
- numeric groups: `[1,2]`, `[1, 2]`, `[1–3]`;
- already-existing Word cross-reference fields;
- parenthetical author-year citations: `(Smith, 2024)`, `(Smith et al., 2024)`;
- narrative author-year citations: `Smith (2024)` or `Smith et al. (2024)`;
- multi-work author-year groups when they can be mapped safely.

Do not treat an arbitrary year or bracketed number as a citation unless it maps credibly to a bibliography source.

For each citation occurrence, record:
- location;
- original visible text;
- citation type;
- source or sources it resolves to;
- confidence of the mapping.

## D. Build the source-identity map

Maintain an internal mapping equivalent to:

```text
source_id
  -> original_reference_entry
  -> stable_bookmark_name
  -> current_reference_position
  -> verified_metadata
  -> every_in_text_citation_location
```

This map is authoritative for all later renumbering.

## E. Create a non-citation content fingerprint

Before changing anything, create a semantic fingerprint of all content outside the reference entries with citation spans removed/replaced by stable placeholders.

The fingerprint should cover as much of the DOCX package as the available tooling permits, including:
- main body text;
- tables;
- headings;
- captions;
- headers and footers;
- footnotes/endnotes;
- text boxes or drawing text when accessible.

Record document structure counts as additional safeguards where possible:
- paragraph count;
- table count;
- figure/image count;
- section count;
- footnote/endnote count;
- heading text/order.

This baseline will be used in G08 to prove that only citations and references changed.

---


# Citation recognition and conversion rules

## Existing numeric citation

Input:

```text
... as demonstrated previously [12].
```

Output conceptually:

```text
... as demonstrated previously [<REF field for source_id>].
```

Do not change the surrounding prose or punctuation.

## Multiple numeric citations

Input:

```text
... has been studied [4, 7].
```

Output:

```text
... has been studied [4], [7].
```

Each number must be its own Word `REF` field.

## Numeric range

Input:

```text
... prior systems [4–6].
```

If the original numbering map establishes the cited sources safely, expand to:

```text
... prior systems [4], [5], [6].
```

After sorting, Word fields may display entirely different numbers; identity, not original number, controls the mapping.

## Parenthetical author-year

Input:

```text
... prior work (Smith and Jones, 2024).
```

If uniquely resolved to a bibliography source:

```text
... prior work [N].
```

Only the citation span changes.

## Narrative author-year

Input:

```text
Smith and Jones (2024) demonstrated ...
```

Output:

```text
Smith and Jones [N] demonstrated ...
```

The narrative author text is substantive prose and must be preserved exactly.

## Ambiguous author-year citation

If `(Smith, 2024)` could refer to multiple bibliography entries and context does not establish which one is intended:
- do not guess;
- do not change the prose;
- record the location and candidate sources in `Reference-Audit.md`;
- preserve the citation until user resolution if a safe mapping cannot be made.

---

# Duplicate detection

Treat references as likely duplicates when strong identity signals agree, for example:
- identical DOI;
- identical normalized title + compatible authors/year;
- publisher metadata proves both entries are the same work.

Do not merge:
- conference paper and later journal extension merely because titles are similar;
- arXiv preprint and published version automatically if they differ materially or the paper intentionally cites both;
- works with similar titles but distinct DOI/venue/year unless evidence proves identity.

When consolidating a duplicate:
1. choose the most complete/verified canonical entry;
2. redirect every citation from both entries to the canonical source bookmark;
3. remove only the redundant bibliography entry;
4. record the action in `Reference-Audit.md`;
5. rerun citation integrity and alphabetization checks.

---

# Reference validation report model

Maintain an internal or output table with fields similar to:

| Final # | Source ID | Short title | Citation count | Metadata | DOI | URL | URL check | Notes |
|---:|---|---|---:|---|---|---|---|---|
| 1 | ... | ... | 3 | VERIFIED | ... | ... | VERIFIED | ... |
| 2 | ... | ... | 1 | CORRECTED | ... | ... | VERIFIED | Corrected year |
| 3 | ... | ... | 2 | UNRESOLVED | — | ... | VERIFIED | Venue conflict |

This report is part of the final quality evidence, not a substitute for inspecting the Word fields themselves.

---

