# Failure Handling, Acceptance Checklist, and Final Summary

# Failure and ambiguity handling

## Structural failures

Examples:
- broken bookmark;
- `REF` field points to wrong source;
- incorrect renumbering;
- non-citation prose changed;
- reference entry split/corrupted during sorting.

**Action:** Stop advancement to the next goal, repair, and rerun the goal's validation gate.

## Bibliographic ambiguity

Examples:
- two works with same author/year and citation lacks disambiguation;
- title in source document is too corrupted to identify confidently;
- publisher and Crossref disagree materially;
- no authoritative URL can be found.

**Action:** Do not invent a resolution. Mark `UNRESOLVED`, preserve source identity/content conservatively, and continue with other references. Clearly disclose unresolved items at the end.

## Web access unavailable

G04, G06, G07, and G10 require external verification/search. If reliable web access is unavailable:
- complete only the passes that can be done safely offline;
- do not claim external validation occurred;
- mark the affected goals incomplete;
- do not fabricate validation results.

---

# Final acceptance checklist

Before delivering outputs, confirm all applicable items:

## Cross-references
- [ ] References use automatic numbering.
- [ ] Each unique source has one stable bookmark/source identity.
- [ ] All safely resolvable citations are real Word `REF` fields.
- [ ] `\n`-style numbered cross-reference behavior is used for numbered reference items.
- [ ] Cross-reference hyperlink behavior is enabled.
- [ ] Multiple citations are discrete: `[1], [2]`.
- [ ] No `Error! Reference source not found.` fields remain.

## Source identity and numbering
- [ ] Citation mapping is source-based, not number-based.
- [ ] Sorting/renumbering did not change what any citation means.
- [ ] Final fields have been updated/verified.
- [ ] Cached display results for skill-created citation `REF` fields match final reference numbers.
- [ ] Skill-created citation fields are not left dirty solely to force recalculation when Word opens the file.
- [ ] The skill did not add/enable `<w:updateFields w:val="true"/>` to refresh citations on open.
- [ ] The skill introduced no external-link field codes (`LINK`, `INCLUDETEXT`, `INCLUDEPICTURE`, `DDE`, `DDEAUTO`, `DATABASE`, `RD`).
- [ ] Normal reference URLs are hyperlinks, not external-update field codes.
- [ ] Open-warning risk audit passes; the generated DOCX should open without the "fields may refer to other files" update prompt caused by this skill.

## References
- [ ] ACM reference formatting applied.
- [ ] Alphabetized by first author/organization with deterministic tie-breaks.
- [ ] Duplicate references handled safely.
- [ ] Uncited references reported.
- [ ] Missing/ambiguous citation targets reported.

## Validation
- [ ] Every reference existence checked.
- [ ] Metadata status assigned to every entry.
- [ ] Strongly supported metadata errors corrected.
- [ ] Ambiguous facts not guessed.
- [ ] Every resolvable reference has a canonical URL.
- [ ] Every URL checked for both reachability and correct work identity.

## Document preservation
- [ ] Non-citation content fingerprint matches preflight baseline.
- [ ] No unrelated prose changes.
- [ ] No unexpected document structure changes.
- [ ] Figures/tables/equations/headings remain intact.
- [ ] Final DOCX rendered and every page visually inspected.

## Outputs
- [ ] `<original-stem>-references-cleaned.docx`
- [ ] `BibTex.md`
- [ ] `references.bib`
- [ ] `Reference-Audit.md`
- [ ] `Suggested-References.md`
- [ ] G10 contains 3–4 verified recommendations and does not alter the Word document.

---

# Final user-facing summary

When the run is complete, provide a concise summary containing:
- number of references processed;
- number of citation occurrences converted to Word cross-references;
- number of duplicate references consolidated;
- number of metadata corrections;
- number of verified URLs;
- any unresolved references/citations;
- confirmation that the non-citation integrity check passed;
- confirmation that the Word field/open-safety audit passed and the skill did not introduce an update-on-open warning dependency;
- links/files for the final DOCX, `BibTex.md`, `references.bib`, `Reference-Audit.md`, and `Suggested-References.md`;
- a brief list of the 3–4 G10 literature suggestions.

Do not claim success for a validation step that was not actually performed.
