# Clean Up References — Portable Agent Skill

This package follows the **Agent Skills open format**. The canonical skill definition is `SKILL.md`; detailed procedures are stored under `references/` and are linked from the main skill.

## Contents

```text
clean-up-references/
├── SKILL.md
├── README.md
└── references/
    ├── PREFLIGHT-AND-CITATIONS.md
    ├── GOALS-G01-G03.md
    ├── GOALS-G04-G07.md
    ├── GOALS-G08-G10.md
    └── FAILURE-AND-ACCEPTANCE.md
```

## Compatibility

Designed for clients that support the Agent Skills open standard, including compatible ChatGPT/OpenAI Skills and Codex workflows and Claude/Claude Code Agent Skills workflows.

The skill itself is portable; execution still depends on the host environment having the capabilities required by the task:

- access to the input `.docx` file;
- ability to create/edit Word bookmarks, numbered paragraphs, and `REF` fields;
- ability to render/inspect the final Word document;
- web/network access for G04, G06, G07, and G10.

If a host lacks one of these capabilities, the skill instructs the agent to mark the affected validation incomplete rather than claim it succeeded.

## Installation concept

Install or upload the **entire `clean-up-references` directory**, or upload the ZIP bundle where the client accepts skill ZIP files. Do not upload only the supporting `references/` files because `SKILL.md` is the entry point.

## Primary outputs when the skill runs

- `<original-stem>-references-cleaned.docx`
- `BibTex.md`
- `references.bib`
- `Reference-Audit.md`
- `Suggested-References.md`

## Version 1.1.0 field/open-safety change

The skill now explicitly prevents a common Microsoft Word warning caused by programmatically enabling field updates on open. It refreshes/caches citation field results before delivery, keeps internal `REF` fields live, avoids leaving skill-created fields dirty solely for open-time recalculation, and does not introduce external-update field codes.
